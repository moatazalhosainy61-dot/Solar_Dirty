SELECT COUNT(*) FROM dbo.dim_governorate;  -- 27
SELECT COUNT(*) FROM dbo.fact_daily;       -- 49329
SELECT COUNT(*) FROM dbo.pvgis_monthly;    -- 324






