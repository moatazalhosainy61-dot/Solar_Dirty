USE SolarEgypt;
GO
SELECT governorate,
       ROUND(AVG(yield_kwh_kwp), 2)    AS avg_yield,
       ROUND(AVG(yield_no_soiling), 2) AS avg_yield_clean,
       ROUND(100.0 * (AVG(yield_no_soiling) - AVG(yield_kwh_kwp)) / AVG(yield_no_soiling), 1) AS soiling_loss_pct,
       ROUND(AVG(cloud_loss) * 100, 1) AS cloud_loss_pct
FROM dbo.fact_daily
GROUP BY governorate
ORDER BY avg_yield DESC;




WITH g AS (
    SELECT governorate,
           AVG(yield_kwh_kwp)    AS y,
           AVG(yield_no_soiling) AS yc
    FROM dbo.fact_daily
    GROUP BY governorate
)
SELECT governorate,
       ROUND(y, 2) AS avg_yield,
       RANK() OVER (ORDER BY y DESC)  AS rank_with_soiling,
       RANK() OVER (ORDER BY yc DESC) AS rank_clean,
       RANK() OVER (ORDER BY y DESC) - RANK() OVER (ORDER BY yc DESC) AS rank_shift
FROM g
ORDER BY rank_with_soiling;



SELECT f.governorate,
       ROUND(AVG(f.yield_kwh_kwp) * 365, 0) AS model_annual,
       ROUND(d.PVGIS_E_Y_kWh_kWp_year, 0)   AS pvgis_annual,
       ROUND(100.0 * (AVG(f.yield_kwh_kwp) * 365 - d.PVGIS_E_Y_kWh_kWp_year) / d.PVGIS_E_Y_kWh_kWp_year, 1) AS diff_pct
FROM dbo.fact_daily f
JOIN dbo.dim_governorate d ON d.GOVERNORATE = f.governorate
GROUP BY f.governorate, d.PVGIS_E_Y_kWh_kWp_year
ORDER BY diff_pct;


SELECT [year], ROUND(AVG(yield_kwh_kwp), 3) AS avg_yield,
       ROUND(AVG(cloud_loss) * 100, 1)       AS cloud_loss_pct
FROM dbo.fact_daily
GROUP BY [year]
ORDER BY [year];





-- على مستوى كل المحافظات
SELECT [month], ROUND(AVG(soiling_loss) * 100, 1) AS avg_soiling_pct
FROM dbo.fact_daily
GROUP BY [month]
ORDER BY avg_soiling_pct DESC;




-- أسوأ شهر لكل محافظة
WITH m AS (
    SELECT governorate, [month], AVG(soiling_loss) AS s,
           ROW_NUMBER() OVER (PARTITION BY governorate ORDER BY AVG(soiling_loss) DESC) AS rn
    FROM dbo.fact_daily
    GROUP BY governorate, [month]
)
SELECT governorate, [month] AS worst_month, ROUND(s * 100, 1) AS soiling_pct
FROM m
WHERE rn = 1
ORDER BY soiling_pct DESC;





-- أسوأ شهر لكل محافظة
WITH m AS (
    SELECT governorate, [month], AVG(soiling_loss) AS s,
           ROW_NUMBER() OVER (PARTITION BY governorate ORDER BY AVG(soiling_loss) DESC) AS rn
    FROM dbo.fact_daily
    GROUP BY governorate, [month]
)
SELECT governorate, [month] AS worst_month, ROUND(s * 100, 1) AS soiling_pct
FROM m
WHERE rn = 1
ORDER BY soiling_pct DESC;



SELECT governorate,
       SUM(CASE WHEN soiling_loss >= 0.05 THEN 1 ELSE 0 END) AS days_above_5pct,
       ROUND(100.0 * SUM(CASE WHEN soiling_loss >= 0.05 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_of_days
FROM dbo.fact_daily
GROUP BY governorate
ORDER BY pct_of_days DESC;




SELECT CASE WHEN rain_mm >= 1 THEN 'Rain day' ELSE 'Dry day' END AS day_type,
       COUNT(*) AS days,
       ROUND(AVG(soiling_loss) * 100, 2) AS avg_soiling_pct
FROM dbo.fact_daily
WHERE rain_mm IS NOT NULL
GROUP BY CASE WHEN rain_mm >= 1 THEN 'Rain day' ELSE 'Dry day' END;





SELECT FLOOR(t_module_peak / 5) * 5 AS module_temp_band,
       COUNT(*) AS days,
       ROUND(AVG(temp_factor), 3)   AS avg_temp_factor,
       ROUND(AVG(yield_kwh_kwp), 2) AS avg_yield
FROM dbo.fact_daily
GROUP BY FLOOR(t_module_peak / 5) * 5
ORDER BY module_temp_band;





SELECT p.[MONTH] AS month_no,
       ROUND(AVG(f.yield_kwh_kwp) * 30.4, 1) AS model_monthly,
       p.PVGIS_E_M_kWh_kWp_month             AS pvgis_monthly
FROM dbo.pvgis_monthly p
JOIN dbo.fact_daily f ON f.governorate = p.GOVERNORATE AND f.[month] = p.[MONTH]
WHERE p.GOVERNORATE = 'Aswan'
GROUP BY p.[MONTH], p.PVGIS_E_M_kWh_kWp_month
ORDER BY p.[MONTH];




WITH g AS (
    SELECT f.governorate, AVG(f.yield_no_soiling) AS yc, d.PVGIS_E_Y_kWh_kWp_year AS pv
    FROM dbo.fact_daily f
    JOIN dbo.dim_governorate d ON d.GOVERNORATE = f.governorate
    GROUP BY f.governorate, d.PVGIS_E_Y_kWh_kWp_year
)
SELECT governorate,
       RANK() OVER (ORDER BY yc DESC) AS rank_model_clean,
       RANK() OVER (ORDER BY pv DESC) AS rank_pvgis
FROM g
ORDER BY rank_pvgis;










