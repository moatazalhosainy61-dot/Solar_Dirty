USE SolarEgypt;
GO
-- عدد المحافظات (المفروض 27)
SELECT COUNT(DISTINCT governorate) AS n_gov FROM dbo.fact_daily;

-- فيه تكرار؟ (المفروض ولا صف)
SELECT governorate, [date], COUNT(*) AS n
FROM dbo.fact_daily
GROUP BY governorate, [date]
HAVING COUNT(*) > 1;

-- الـ nulls في المطر (المفروض 5)
SELECT COUNT(*) AS null_rain FROM dbo.fact_daily WHERE rain_mm IS NULL;



-- المفروض ولا صف
SELECT DISTINCT f.governorate
FROM dbo.fact_daily f
LEFT JOIN dbo.dim_governorate d ON d.GOVERNORATE = f.governorate
WHERE d.GOVERNORATE IS NULL;







